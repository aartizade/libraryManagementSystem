package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.database.ConnectionDb;
import com.entity.LibraryEntity;

public class LibraryDao {
	private Connection conn;

	public LibraryDao() {
		try {
			this.conn=ConnectionDb.connectDb();
			createTableIfNotExists();
			
		}catch(Exception e) {
			e.printStackTrace();
			
		}
		
	}

	private void createTableIfNotExists() {
		String str1="Create Table if not exists libraryManagement("+
				 "mId BIGINT PRIMARY KEY,"+
				"mName varchar (80),"+
				 "bookname varchar(90),"+
				"authorname varchar(80),"+
				 "phoneNo BIGINT,"+
				"price BIGINT)";
		try {
			PreparedStatement ps=conn.prepareStatement(str1);
			ps.execute();
		}catch(Exception e) {
			e.printStackTrace();
			System.err.println("createTableIfNotExists method error");
		}
				
		
	}
	public void insertMemberDetails(LibraryEntity obj) 
	{
		String query="INSERT INTO librarymanagement(mId,mName,bookName,authorName,phoneNo,price)"+
	"vALUES(?,?,?,?,?,?)";
		try(PreparedStatement ps=conn.prepareStatement(query)){
			ps.setLong(1, obj.getmId());
			ps.setString(2,obj.getmName());
			ps.setString(3,obj.getBookName());
			ps.setString(4,obj.getAuthorName());
			ps.setLong(5,obj.getPhoneNo());
			ps.setLong(6, obj.getPrice());
			ps.executeUpdate();
			System.out.println("Member add sucessfuly");
			
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}
	public LibraryEntity getMemberById(long mId) {
		String sql="SELECT* FROM libraryManagement WHERE mId=?";
		try(PreparedStatement statement =conn.prepareStatement(sql)) {
			statement.setLong(1, mId);
			ResultSet resultSet = statement.executeQuery();
			if(resultSet.next()) 
			{
				LibraryEntity emp1=new LibraryEntity();
				emp1.setmId(resultSet.getLong("mId"));
				emp1.setmName(resultSet.getString("memberName"));
				emp1.setBookName(resultSet.getString("BookName"));
				emp1.setAuthorName(resultSet.getString("AuthorName"));
				emp1.setPhoneNo(resultSet.getLong("phoneNo"));
				emp1.setPrice(resultSet.getLong("price"));
				return emp1;
				
			}
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}return null ;
		}
	
	public void deleteMember(long mId) {
		String sql="DELETE FROM libraryManagement WHERE mId=?";
		try(PreparedStatement statement =conn.prepareStatement(sql)) {
			statement.setLong(1, mId);
			int rowDeleted =statement.executeUpdate();
			if(rowDeleted>0) {
				System.out.println("member del."
						+ "ete successfully");
			}else {
				System.out.println("Employee not found or delete failed");
			}
			
			
		}catch(Exception e) {
			
		}
	}
	
	public void updateMember(LibraryEntity emp) {
		String sql ="UPDATE libraryManagement SET mName=?,bookName=?,authorName=?,phoneNo=?,price=? WHERE mId=?";
		try(PreparedStatement statement =conn.prepareStatement(sql)){
			statement.setString(1,emp.getmName());
			statement.setString(2,emp.getBookName());
			statement.setString(3,emp.getAuthorName());
			statement.setLong(4,emp.getPhoneNo());
			statement.setLong(5,emp.getPrice());
			statement.setLong(6,emp.getmId());
			int rowsUpdated = statement.executeUpdate();
			if(rowsUpdated>0) {
				System.out.println("Member Udated in Libraray");
			}else {
				System.out.println("Member Not Found");
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
	}
	public ArrayList<LibraryEntity>fetchMember(){
		ArrayList<LibraryEntity> empList = new ArrayList<>();
		String sql = "SELECT * FROM libraryManagement";
		try(PreparedStatement statement = conn.prepareStatement(sql)){
			ResultSet resultSet = statement.executeQuery();
			while(resultSet.next()) {
				LibraryEntity emp = new LibraryEntity();
				emp.setmId(resultSet.getLong("mId"));
				emp.setmName(resultSet.getString("mName"));
				emp.setBookName(resultSet.getString("bookName"));
				emp.setAuthorName(resultSet.getString("authorName"));
				emp.setPhoneNo(resultSet.getLong("phoneNo"));
				emp.setPrice(resultSet.getLong("Price"));
				
				empList.add(emp);
			}
		}catch(Exception e) {
			e.printStackTrace();
		}return empList;
		
	}
		
	}

	
	
	

