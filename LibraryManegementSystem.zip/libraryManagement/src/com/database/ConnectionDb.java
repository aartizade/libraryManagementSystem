package com.database;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectionDb {
	
	public static Connection connectDb() {
		try {
			String ur1="jdbc:mysql://localhost:3306/tb1";
			String userName="root";
			String password="root";
			Connection con=DriverManager.getConnection(ur1,userName,password);
			System.out.println("Connected tp the database");
			return con;
			}catch(Exception e) 
		{
			e.printStackTrace();	
		}
		return null;
	}

}
