package com.services;

import java.util.ArrayList;
import java.util.Scanner;

import com.dao.LibraryDao;
import com.entity.LibraryEntity;

public class LibrarayServices {
	private LibraryDao librarydao;
	private Scanner scanner;
	public LibrarayServices(LibraryDao librarydao, Scanner scanner) {
		super();
		this.librarydao = librarydao;
		this.scanner = scanner;
	}
	public void addMember() {
		try {
			System.out.println("enter member Details");
			System.out.print("mId:");
			long mId= scanner.nextLong();
			
			scanner.nextLine();
			System.out.print("memberName");
			String mName = scanner.nextLine();
			scanner.nextLine();
			
			System.out.print("BookName");
			String bookName = scanner.nextLine();
			scanner.nextLine();
			System.out.print("authorName");
			String authorName = scanner.nextLine();
			scanner.nextLine();
			System.out.print("phoneNo");
			long phoneNo = scanner.nextLong();
			scanner.nextLine();
			System.out.print("price");
			long price = scanner.nextLong();
			scanner.nextLine();
			
			
			LibraryEntity member = new LibraryEntity(mId,mName,bookName,authorName,phoneNo,price);
			librarydao.insertMemberDetails(member);
			System.out.println("Member added sucessfully");
					
					
		}catch(Exception e) {
			System.out.println("error while adding member:"+e.getMessage());
			e.printStackTrace();
			
		}
	}
	public void deleteMember() 
	{
		try {
			System.out.print("Enter memberId to delete member");
			int mId = scanner.nextInt();
			librarydao.deleteMember(mId);
			System.out.println("Member Deleted succsessfuly.");
			
			
		}catch(Exception e) {
			System.out.println("error while deleting member:"+e.getMessage());
			e.printStackTrace();
			
		}
	}
	public void updateMember() {
		try {
		System.out.print("Enter MID to update member");
		int mId=scanner.nextInt();
		LibraryEntity member =librarydao.getMemberById(mId)	;
		if(member!=null) {
			System.out.println("Enter Updated details");
			System.out.print("MemberName");
			member.setmName(scanner.next());
			System.out.print("BookName");
			member.setBookName(scanner.next());
			System.out.print("AuthorName");
			member.setAuthorName(scanner.next());
			System.out.print("PhoneNo");
			member.setPhoneNo(scanner.nextLong());
			System.out.print("Price");
			member.setPrice(scanner.nextLong());
			librarydao.updateMember(member);
			System.out.println("member updated successfully.");
			
			}else {
				System.out.println("member not found");
			}
		}catch(Exception e) {
			System.err.println("error while updating member"+e.getMessage());
			e.printStackTrace();
		}
		
	}
	public void fetchMember() {
		try {
			ArrayList<LibraryEntity>members=librarydao.fetchMember();
			System.out.println("Member List");
			for(LibraryEntity member:members) {
				System.out.println(member);
				
			}
		}catch(Exception e) {
			System.out.println("error while fetching");
			e.printStackTrace();
		}
	}
	public void getMemberById() {
		try {
			System.out.print("Enter MID to get member details:");
			int mId=scanner.nextInt();
			LibraryEntity member =librarydao.getMemberById(mId)	;
			if(member!=null) {
				
				System.out.println("member Details:"+member);
				
				}else {
					System.out.println("member not found");
				}
			}catch(Exception e) {
				System.err.println("error while retriving member details"+e.getMessage());
				e.printStackTrace();
			}
			
		
	}
	
	
	

}
