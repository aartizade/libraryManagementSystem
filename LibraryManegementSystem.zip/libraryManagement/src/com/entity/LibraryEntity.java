package com.entity;

public class LibraryEntity {
	private long mId;
	private String mName;
	private String bookName;
	private String authorName;
	private long phoneNo;
	private long price;
	public LibraryEntity() {
		super();
		
	}
	public LibraryEntity(long mId, String mName, String bookName, String authorName, long phoneNo, long price) {
		super();
		this.mId = mId;
		this.mName = mName;
		this.bookName = bookName;
		this.authorName = authorName;
		this.phoneNo = phoneNo;
		this.price = price;
	}
	public long getmId() {
		return mId;
	}
	public void setmId(long mId) {
		this.mId = mId;
	}
	public String getmName() {
		return mName;
	}
	public void setmName(String mName) {
		this.mName = mName;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public long getPrice() {
		return price;
	}
	public void setPrice(long price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "LibraryEntity [mId=" + mId + ", mName=" + mName + ", bookName=" + bookName + ", authorName="
				+ authorName + ", phoneNo=" + phoneNo + ", price=" + price + "]";
	}
	
	

}
