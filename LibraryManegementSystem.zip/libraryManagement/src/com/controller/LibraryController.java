package com.controller;

import java.util.Scanner;

import com.dao.LibraryDao;
import com.services.LibrarayServices;

public class LibraryController {
	

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		LibraryDao libraryDao =new LibraryDao();
		LibrarayServices libraryService =new LibrarayServices(libraryDao,scanner);
		try {
			while(true) {
				printMenu();
				int choice = scanner.nextInt();
				switch(choice) {
				case 1 :
					libraryService.addMember();
					break;
				case 2:
					libraryService.getMemberById();
					break;
				case 3:
					libraryService.deleteMember();
					break;
				case 4:
					
					libraryService.updateMember();
					break;
				case 5:
					libraryService.fetchMember();
					break;
				case 0:
					System.out.println("exit library.");
					System.exit(0);
					break;
					default:
						System.out.println("Invalid choice.pls enter valid option.");
					
				
				}
			}
			
		}finally {
			scanner.close();
		}
		
	}

	private static void printMenu() {
		System.out.println("1.Add Member");
		System.out.println("2.Get member by Id");
		System.out.println("3.Delete member");
		System.out.println("4.update member");
		System.out.println("5.fetch all member");
		System.out.println("6.Exit");
		System.out.println("Enter your choice:-");
		
			
		
	}

	

}
